import os
import bson
from bson.objectid import ObjectId
import json
import pymongo
from pymongo import MongoClient, errors

import time
from datetime import date, timedelta, datetime
from decimal import *
from flask import Flask, session, render_template, request, redirect, url_for, jsonify, escape
from flask_socketio import SocketIO
from flask_socketio import send, emit
from werkzeug.exceptions import HTTPException
import sys
import jinja2
import numpy as np 
import pprint
import socket 
import pyodbc  
import pprint
from flask_cors import CORS
from flask import Blueprint
from os import path, walk
from pathlib import Path

import config_banco_de_dados
from config_banco_de_dados import *





def retorna_cotacao_USD_moedas():
    ultima_cotacao = []
    for cotacoes in col_cotacao_USD_moedas.find().sort([("data_ts", pymongo.DESCENDING)]): # ("data_ts", pymongo.ASCENDING),  # DESCENDING
        print('ultima cotacao retorna_cotacao_USD_moedas: ')
        print(cotacoes)
        ultima_cotacao.clear()
        ultima_cotacao.append(cotacoes)
        return ultima_cotacao

#cotacaoDoDia = retorna_cotacao_USD_moedas()

#print(cotacaoDoDia[0]['USD_BRL'])



def retorna_valor_BTC_exchanges():
    ultima_cotacao = []
    for cotacoes in col_valor_BTC_exchanges.find(): # ("data_ts", pymongo.ASCENDING),  # DESCENDING
        #print('ultima cotacao col_valor_BTC_exchanges: ')
        #print(cotacoes)
        ultima_cotacao.clear()
        ultima_cotacao.append(cotacoes)

    print('ultima cotacao poloniex retorna_valor_BTC_exchanges...:')
    print(ultima_cotacao[0]['btc_markets']['0'])

    poloniex = ultima_cotacao[0]['btc_markets']['0']['poloniex']
    bitcambio = ultima_cotacao[0]['btc_markets']['0']['bitcambio']
    bitstamp = ultima_cotacao[0]['btc_markets']['0']['bitstamp']
    bittrex = ultima_cotacao[0]['btc_markets']['0']['bittrex']
    blockchain = ultima_cotacao[0]['btc_markets']['0']['blockchain']
    braziliex = ultima_cotacao[0]['btc_markets']['0']['braziliex']
    cex = ultima_cotacao[0]['btc_markets']['0']['cex']
    gemini = ultima_cotacao[0]['btc_markets']['0']['gemini']
    kraken = ultima_cotacao[0]['btc_markets']['0']['kraken']
    mercadobtc = ultima_cotacao[0]['btc_markets']['0']['mercado btc']
    okcoin = ultima_cotacao[0]['btc_markets']['0']['okcoin']
    binance = ultima_cotacao[0]['btc_markets']['0']['binance']
    hitbtc = ultima_cotacao[0]['btc_markets']['0']['hitbtc']


    ultima_cotacao.clear()
    ultima_cotacao.append({
        'bitcambio':bitcambio,
        'bitstamp':bitstamp,
        'bittrex':bittrex,
        'blockchain':blockchain,
        'braziliex':braziliex,
        'cex':cex,
        'gemini':gemini,
        'kraken':kraken,
        'mercadobtc':mercadobtc,
        'okcoin':okcoin,
        'hitbtc':hitbtc,
        'binance':binance,
        'poloniex':poloniex

        })


    return ultima_cotacao


#retorna_valor_BTC_exchanges()



def retorna_USD_BRL():
    valor_USD_BRL = 0
    for moedas in col_cotacao_USD_moedas.find():
        valor_USD_BRL = moedas['USD_BRL']
    print('valor_USD_BRL retorna_USD_BRL...')
    print(valor_USD_BRL)
    return valor_USD_BRL

#retorna_USD_BRL()






def retorna_lista_statistics():
    print('retorna_lista_statistics...')
    lista_bots = ['my_bot_25', 'my_bot_teste']
    lista_bots_consulta = []
    for dados in col_bot_configuracao.find():
        bot_name = dados['bt_name']
        bot_trades = dados['trades']
        bot_statistics = dados['statistics']
        if bot_name in lista_bots:
            lista_bots_consulta.append({
                'bot_name':bot_name,
                'bot_trades':bot_trades,
                'bot_statistics':bot_statistics
            })
    return lista_bots_consulta


