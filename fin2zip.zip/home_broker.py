import os
import bson
from bson.objectid import ObjectId
import json
from pymongo import MongoClient, errors
import time
from datetime import date, timedelta, datetime
from decimal import *
from flask import Flask, session, render_template, request, redirect, url_for, jsonify, escape
from flask_socketio import SocketIO
from flask_socketio import send, emit
from werkzeug.exceptions import HTTPException
import sys
import jinja2
import numpy as np 
import pprint
import socket 
import pyodbc  
import pprint
from flask_cors import CORS
from flask import Blueprint
from os import path, walk
from pathlib import Path

from home_broker_consultas import *
from polo_bot import *
from all_tickers_btc_usdt import *
from funcoes_login import *

from config_banco_de_dados import *



homebroker = Flask(__name__)
CORS(homebroker)
homebroker.secret_key = os.urandom(24) # b'5#y2L"F4Q8zfxpppxex]/'
pasta_local_templates = str(Path(__file__).parent.absolute()) + '\\Templates' 
pasta_local_imgs = str(Path(__file__).parent.absolute()) + '\\imgs' 
#homebroker = Blueprint('homebroker',__name__, url_prefix="/homebroker", template_folder=pasta_local_templates, static_folder=pasta_local_imgs, static_url_path=pasta_local_imgs) #  static_folder="imgs"
homebroker = Blueprint('homebroker',__name__, url_prefix="/homebroker", template_folder=pasta_local_templates, static_folder="imgs", static_url_path = "/imgs", ) #  static_folder="imgs"



global lista_btc_exchanges 
lista_btc_exchanges = []





@homebroker.route('/')
def index():
    print('index...')
    # user, interval, pair1, pair2, buy_percent, sell_percent, up, down  
    # lista_trades, statistics = profit_bt2('dan01', 86400, 'USDT', 'BTC', 100, 100, 500, 500)

    cotacao_usd_moedas = retorna_cotacao_USD_moedas()
    lista_exchanges = retorna_valor_BTC_exchanges() 
    lista_e2e = menor_e_maior_valor_exchanges(lista_exchanges)
    lista_bots_statistics = retorna_lista_statistics()

    #return render_template("testes.html", lista_trades=lista_trades, statistics=statistics, lista_exchanges=lista_exchanges, lista_e2e=lista_e2e) # index.html
    #return render_template("testes.html", lista_trades=lista_trades, statistics=statistics, lista_exchanges=lista_exchanges, cotacao_usd_moedas=cotacao_usd_moedas, lista_e2e=lista_e2e) # index.html
    return render_template("testes2.html", lista_exchanges=lista_exchanges, cotacao_usd_moedas=cotacao_usd_moedas, lista_e2e=lista_e2e, lista_bots_statistics=lista_bots_statistics) # index.html


'''

@homebroker.route('/')
def index():
    print('index...')

    return "homeBroker..." # index.html     testes.html

'''


def menor_e_maior_valor_exchanges(listaExchanges):
    binance = listaExchanges[0]['binance']
    hitbtc = listaExchanges[0]['hitbtc']
    poloniex = listaExchanges[0]['poloniex']
    kraken = listaExchanges[0]['kraken']
    okcoin = listaExchanges[0]['okcoin']
    mercadobtc = listaExchanges[0]['mercadobtc']
    bitcambio = listaExchanges[0]['bitcambio']
    braziliex = listaExchanges[0]['braziliex']
    blockchain = listaExchanges[0]['blockchain']
    bitstamp = listaExchanges[0]['bitstamp']
    bittrex = listaExchanges[0]['bittrex']
    cex = listaExchanges[0]['cex']
    gemini = listaExchanges[0]['gemini']

    lista_valores = [{   'exchange':'binance',
            'valor':binance
        },
        {
            'exchange':'hitbtc',
            'valor':hitbtc
        },
        {
            'exchange':'poloniex',
            'valor':poloniex
        },
        {
            'exchange':'kraken',
            'valor':kraken
        },
        {
            'exchange':'okcoin',
            'valor':okcoin
        },
        {
            'exchange':'mercadobtc',
            'valor':mercadobtc
        },
        {
            'exchange':'bitcambio',
            'valor':bitcambio
        },
        {
            'exchange':'braziliex',
            'valor':braziliex
        },
        {
            'exchange':'blockchainLux',
            'valor':blockchain
        },
        {
            'exchange':'bitstamp',
            'valor':bitstamp
        },
        {
            'exchange':'bittrex',
            'valor':bittrex
        },
        {
            'exchange':'cex',
            'valor':cex
        },
        {
            'exchange':'gemini',
            'valor':gemini
        }]


    exchange_menor_valor = ''
    menor_valor = 999999999999

    for dados in lista_valores:
        exchange = dados['exchange']
        valor = dados['valor'] 
        if valor < menor_valor and valor > 0:
            menor_valor = valor
            exchange_menor_valor = exchange


    exchange_maior_valor = ''
    maior_valor = 0

    for dados in lista_valores:
        exchange = dados['exchange']
        valor = dados['valor'] 
        if valor > maior_valor:
            maior_valor = valor
            exchange_maior_valor = exchange

    best_usdt_profit = round(float(maior_valor) - float(menor_valor), 2)
    porcentagem_lucro_apos_e2e = round((float(menor_valor) / 100) / best_usdt_profit, 2)

    e2e_best_trade = [{'exchange_menor_valor':exchange_menor_valor, 'menor_valor':menor_valor, 'exchange_maior_valor':exchange_maior_valor, 'maior_valor':maior_valor, 'best_usdt_profit':best_usdt_profit, 'porcentagem_lucro_apos_e2e':porcentagem_lucro_apos_e2e}]

    return e2e_best_trade





@homebroker.route('/btc_chart', methods=['POST', 'GET'])
def btc_chart():
    print('btc_chart...')

    lista_exchanges = start_local(yahoo_dolar) 
    lista_btc_exchanges=lista_exchanges

    print('lista_exchanges')
    print(lista_exchanges)

    return render_template("chart_btc.html", lista_exchanges=lista_exchanges)





@homebroker.route('/signin', methods=['POST', 'GET'])
def signin_page():
    print('signin...')
    try:
        if request.method == 'POST':
            usuario_logado = request.form['login']
            usuario_logado_senha = request.form['senha']

            if len(usuario_logado)>0 and len(usuario_logado_senha)>0:
                # login
                resultado_login = login(usuario_logado, usuario_logado_senha)

                if resultado_login ==1:
                    # entra no site / carrega dados p site
                    print('entra no site...')
                    return redirect('homebroker/pg_de_usuario')

        else:
            return render_template("signin.html")


        
    except Exception as er:
        pass
        return render_template("signin.html")





@homebroker.route('/pg_de_usuario', methods=['POST', 'GET']) # , methods=['POST', 'GET']
def pg_de_usuario():
    print('pg_de_usuario...')
    '''
    # ===== 2019
    lista_trades2, statistics2 = profit_bt2('dan02', 86400, 'USDT', 'BTC', 100, 100, 500, 500)

    lista_trades3, statistics3 = profit_bt2('dan03', 86400, 'USDT', 'BTC', 50, 50, 1000, 1000)

    lista_trades4, statistics4 = profit_bt2('dan04', 86400, 'USDT', 'BTC', 80, 80, 1000, 500)

    lista_trades5, statistics5 = profit_bt2('dan05', 86400, 'USDT', 'BTC', 75, 75, 800, 800)

    # ====== 2020

    lista_trades_2020_1, statistics_2020_1 = profit_bt2_2020('dan05', 86400, 'USDT', 'BTC', 75, 75, 800, 800)

    lista_trades_2020_2, statistics_2020_2 = profit_bt2_2020('dan05', 86400, 'USDT', 'BTC', 100, 100, 800, 800)

    
    print('end of page...')

    return render_template("homebroker.html", 
    lista_trades2=lista_trades2, statistics2=statistics2, lista_trades3=lista_trades3,statistics3=statistics3, lista_trades4=lista_trades4,statistics4=statistics4, lista_trades5=lista_trades5, statistics5=statistics5,
    lista_trades_2020_1=lista_trades_2020_1, statistics_2020_1=statistics_2020_1, lista_trades_2020_2=lista_trades_2020_2, statistics_2020_2=statistics_2020_2)
    '''
    return render_template("homebroker.html")



@homebroker.route('/signup', methods=['POST', 'GET'])
def signup():
    print('signup...')
    try:
        if request.method == 'POST':
            usuario_logado = request.form['name']
            usuario_nome_publico = request.form['public_name']
            usuario_email = request.form['email']
            usuario_senha1 = request.form['pass1']
            usuario_senha2 = request.form['pass2']
            usuario_phone = request.form['phone']

            if not usuario_senha1 == usuario_senha2:
                mensagem_erro='Password not equals.'
                return render_template("signup.html", mensagem_erro=mensagem_erro)
            
            if not len(usuario_nome_publico)>2:
                mensagem_erro='At least 3 letters needed for public name.'
                return render_template("signup.html", mensagem_erro=mensagem_erro)  

            if len(usuario_logado)>0 and len(usuario_nome_publico)>0 and len(usuario_email)>0 and len(usuario_senha1)>0 and len(usuario_phone)>0:

                # cadastra usuario
                status_cadastro = cadastro_de_usuario(usuario_nome_publico, usuario_senha1, usuario_email)
                if status_cadastro == 1:
                    mensagem_welcome = 'Welcome '+ str(usuario_nome_publico)
                    return render_template("signin.html", mensagem_welcome=mensagem_welcome)  


            else:
                mensagem_erro='Fill all fields.'
                return render_template("signup.html", mensagem_erro=mensagem_erro)                             


        else:
            return render_template("signup.html")


        
    except Exception as er:
        pass
        print('erro em cadastrar novo usuario...' + str(er))
        mensagem_erro='ops. Algo de errado ocorreu. Tente novamente.'
        return render_template("signup.html", mensagem_erro=mensagem_erro)





@homebroker.route('/analise_bots', methods=['POST', 'GET'])
def analise_bots():
    bot_configuracao = []
    for bots_configuracoes in col_bot_configuracao.find({'user':'web_app', 'bt_name':'my_bot_02'}): #'web_app', 'my_bot_02'
        bot_configuracao.append(bots_configuracoes)
        print(bot_configuracao)
        #return bot_configuracao
    return render_template("analise_bots.html", bot_configuracao=bot_configuracao)








##########################################
### poloniex ticker ######################
##########################################

@homebroker.route('/poloniex_ticker', methods=['POST', 'GET'])
def consulta_poloniex_ticker():
    ticker = poloniex_ticker(http)
    return ticker


